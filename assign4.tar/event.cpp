/*********************************************************************
** Program Filename: event.cpp
** Author: Brandon Christensen
** Date: 5/25/2020
** Description: no functions as it is pure virtual
** Input: none
** Output: none
*********************************************************************/