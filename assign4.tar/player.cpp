/*********************************************************************
** Program Filename: player.cpp
** Author: Brandon Christensen
** Date: 5/25/2020
** Description: Functions related to the player class
** Input: none
** Output: none
*********************************************************************/
#include <iostream>
#include "player.h"

Entrance::Entrance(){

} 

Entrance::~Entrance(){

}

void Entrance::set_name(char name){

}

void Entrance::percept(){

}

void Entrance::encounter(){

}